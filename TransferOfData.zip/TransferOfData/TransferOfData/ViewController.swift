//
//  ViewController.swift
//  TransferOfData
//
//  Created by IACD-017 on 2022/05/19.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var moveScreenButton: UIButton!
    
    @IBOutlet var HomeTextField: UITextField!
    
    
    @IBOutlet var sendButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

