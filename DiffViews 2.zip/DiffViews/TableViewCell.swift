//
//  TableViewCell.swift
//  DiffViews
//
//  Created by IACD-017 on 2022/07/29.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var logo: UIImageView!
    @IBOutlet weak var clubNameLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var clubSummary: UILabel!
    @IBOutlet weak var joinButton: UIButton!
    
}
