//
//  ViewController.swift
//  DiffViews
//
//  Created by IACD-017 on 2022/07/28.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{

    @IBOutlet weak var socialTabel: UITableView!
    
    struct Socials {
        let logoName:String
        let clubName: String
        let dateOfPost: String
        let clubSummary: String
    }
    
    let socialData:[Socials] = [
    Socials(logoName: "logo1", clubName: "Swimmers Club",dateOfPost: "22 June 2022", clubSummary: "We swim in water. It's fun. We meet on Thursdays at Room 22 of Building C."),
    Socials(logoName: "logo2", clubName: "Chess Club", dateOfPost: "2 July 2022", clubSummary: "Use your queen to lead your kingdom to victory. Or be a boss and use a pawn instead. We meet on Thursdays at Room 22 of Building C."),
    Socials(logoName: "logo3", clubName: "Artist Club", dateOfPost: "22 August 2022", clubSummary: "We make music, drawings, paintings and crafts. We meet on Thursdays at Room 22 of Building C."),
    Socials(logoName: "logo4", clubName: "Doodle Club", dateOfPost: "16 March 2022", clubSummary: "We just relax and make quick sketches or doodles. We meet on Thursdays at Room 22 of Building C.")
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        socialTabel.dataSource = self
        socialTabel.delegate = self
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return socialData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let clubs = socialData[indexPath.row]
        let cell = socialTabel.dequeueReusableCell(withIdentifier: "socialCell", for: indexPath) as!TableViewCell
        
        cell.clubNameLabel.text = clubs.clubName
        cell.dateLabel.text = clubs.dateOfPost
        cell.clubSummary.text = clubs.clubSummary
        //cell.logo.image = UIImage(named: clubs.logoName)
        
        return cell
    }

    
}

