//
//  ViewController.swift
//  vieiwie
//
//  Created by IACD-017 on 2022/08/14.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

