//
//  ContentView.swift
//  UI Project1
//
//  Created by IACD-017 on 2022/08/04.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
      
        VStack(alignment: .center, spacing: 0) {
            
            HStack{
                Text("Login")
                    .font(.title)
                    .fontWeight(.semibold)
                    .multilineTextAlignment(.center)
                Text("Welcome")
                    .font(.headline)
                    .fontWeight(.semibold)
                    .multilineTextAlignment(.trailing)
            }
            Spacer()
            Image("Email")
            Image("FB")
            Image("Google")
            
        }
        
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
