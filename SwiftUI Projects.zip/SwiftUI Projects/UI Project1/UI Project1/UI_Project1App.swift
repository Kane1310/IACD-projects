//
//  UI_Project1App.swift
//  UI Project1
//
//  Created by IACD-017 on 2022/08/04.
//

import SwiftUI

@main
struct UI_Project1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
