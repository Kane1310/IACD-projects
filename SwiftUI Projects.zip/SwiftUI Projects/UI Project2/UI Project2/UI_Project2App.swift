//
//  UI_Project2App.swift
//  UI Project2
//
//  Created by IACD-017 on 2022/08/09.
//

import SwiftUI

@main
struct UI_Project2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
