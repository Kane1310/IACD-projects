//
//  ContentView.swift
//  UI Project2
//
//  Created by IACD-017 on 2022/08/09.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack(spacing: 10){
            Text("Dices")
                .font(.largeTitle)
                .fontWeight(.bold)
                .multilineTextAlignment(.center)
            HStack(spacing: 20){
                Image("dice1")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                Image("dice2")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            }
            
            HStack(spacing: 80){
                Text("Count ")
                    .font(.title)
                Text("3")
                    .font(.title3)
                    .fontWeight(.semibold)
                    .multilineTextAlignment(.trailing)
            }
            Button {
                <#code#>
            } label: {
                Text("Roll")
            }

            HStack(spacing: 80){
                Text("Rounds ")
                    .font(.title)
                Text("3")
                    .font(.title3)
                    .fontWeight(.semibold)
                    .multilineTextAlignment(.trailing)
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
