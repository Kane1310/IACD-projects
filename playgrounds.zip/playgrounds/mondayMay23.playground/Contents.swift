import UIKit


/////////////////////////////////////////////////////////////////////////////// //// ///////////////////////////////////////////////////////////////////////////////////////// /// ///////////////////////////////////////////////////////////////////////// /// ////////////////////////////
//an Enum & switch statements

enum priority {
    case emergancy
    case high
    case medium
    case low
}

enum progression{
    case complete
    case incomplete
    case progressing
    case starting
    case finishing
//in order starting, progressing, finishing, progressing, complete or incomplete
}

var myProgressStatus: progression = .complete

func encouragement(myProgressStatus: progression) {
    
    switch myProgressStatus{
        case .starting:
        print("We have begun")
    case .progressing:
        print("We are making progress")
    case .finishing:
        print("Nearly there!")
    case .complete:
        print("WE'RE DONE!!")
    case .incomplete :
        print("We'll get it done soon.")
    
    }
}

encouragement(myProgressStatus: myProgressStatus)

/////////////////////////////////////////////////////////////////////////////// //// ///////////////////////////////////////////////////////////////////////////////////////// /// ///////////////////////////////////////////////////////////////////////// /// ////////////////////////////
//Classism


//Note 1: diff btwn class & struct, refrence type & value type
class water{
    let element: String
    let state : String
    //init- is an initalizer, kinda like a construct(swift vers)
    init(element: String, state: String) {
        //self - assign the value from the parameter to the constant we made earlier
        self.element = element
        self.state = state
    }
}

var iceClass: water = water(element: "hydrogen dioxyde", state: "frozen")
var water2 = iceClass //this will refer to iceClass, n if iceClass is changed so will water2


struct waterStruct{
    let element: String
    let state : String
    //init- is an initalizer, kinda like a construct(swift vers)
    init(element: String, state: String) {
        //self - assign the value from the parameter to the constant we made earlier
        self.element = element
        self.state = state
    }
}

var ice: waterStruct = waterStruct(element: "hydrogen dioxyde", state: "frozen")
var water3 = ice //this basicaly makes a copy of ice, it will reflect what ice currently is. If ice changes, water3 stays the same


/////////////////////////////////////////////////////////////////////////////// //// ///////////////////////////////////////////////////////////////////////////////////////// /// ///////////////////////////////////////////////////////////////////////// /// ////////////////////////////
//loop deloops


let fullnames = ["Candy","Carel","Josh","Pieke"]

//a for loop - the names(can be called whatever you like, its a var
for names in fullnames{
    print(names)
}

var nameCount = fullnames.count
//a while loop
while nameCount > 0{
    print(nameCount)
    nameCount -= 1
}



/////////////////////////////////////////////////////////////////////////////// //// ///////////////////////////////////////////////////////////////////////////////////////// /// ///////////////////////////////////////////////////////////////////////// /// ////////////////////////////
//is it Optional to wrap(optionals and wraps)

//opt -> is a type that tells swift that something is "*shrug*idk, i guess it's that"
//if u remove the ?, you will get an error on the second line cause string? is diff from string. it expects that type if ? is not there, when its there its like, okay cool i guess.
var pet: String? = nil

// but because opts are not the same as the type, this means it wont act the same despite having the same name
    //u have to unwrap optionals to use them in the way that is expected of the type
 var num1: Int? = 34
var num2: Int? = 3
// how u can unwrap
if let xyz = num1{
    if let yxz = num2{
        let sum = xyz + yxz
        print(sum)
    } else{
        print("damn bro u got no numbers")
    }
}



/////////////////////////////////////////////////////////////////////////////// //// ///////////////////////////////////////////////////////////////////////////////////////// /// ///////////////////////////////////////////////////////////////////////// /// ////////////////////////////
//an Guard statements

//basically works like an if else but written diff.
var number = 6

func isItBiggerThan5(number: Int)->Bool{
    // translating -> if the number is less than 5 it returns false but if it is more than 5 it moves to the else and reutrns true
    guard number < 5 else {  // note you can add more statements to guard -> number <5, number >0 etc
        return true
    }
    return false
}

//also can be used to unwrap opts

var car: String? = nil

func unwrapping(car: String?) {
    guard let car = car else { return print("no cars bro?") }
    return print("there is a \(car)")
}


/////////////////////////////////////////////////////////////////////////////// //// ///////////////////////////////////////////////////////////////////////////////////////// /// ///////////////////////////////////////////////////////////////////////// /// ////////////////////////////
//Protocol
// datasource and delegate is a naming convention, though it can be changed up
//delgate-> houses func for user interactions
//datasource-> deals with data

protocol Task{
    var date: Date {get set}
    var taskName: String {get set}
    
    func encouragement()
    func taskStatus() -> Bool
}


class Routine: Task{
    var date: Date
    var taskName: String
    
    init(taskName: String, date: Date) {
        self.taskName = taskName
        self.date = date
    }
    
    func encouragement() {
        //stuff
    }
    
    func taskStatus() -> Bool {
        //stuff
        return true
    }
}


/////////////////////////////////////////////////////////////////////////////// //// ///////////////////////////////////////////////////////////////////////////////////////// /// ///////////////////////////////////////////////////////////////////////// /// ////////////////////////////
//Array n Dicktonariiiees

//array

var bats: [String] = ["fruit", "flying rat", "flying dogs"]
var dumbStuff: [Any] = ["brid", 0, 35.36, "cat"]

//dickt
//same by it works as a key: value pair
var animals: [String: Int] = ["bird": 5, "cat":6 ,"spider": 11111]


/////////////////////////////////////////////////////////////////////////////// //// ///////////////////////////////////////////////////////////////////////////////////////// /// ///////////////////////////////////////////////////////////////////////// /// ////////////////////////////
//
