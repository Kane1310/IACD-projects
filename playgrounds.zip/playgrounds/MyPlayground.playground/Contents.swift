import UIKit

var arr: [Int] = [1,2,-3,4,1,2,3,5,6,5,6]
 let arr2D: [[Int]] = [[1,2,3,4,5,6],[11,12,13,14,15,23],[9,10,11,12,13,14],[11,12,13,14,15,23],[13,14,15,23,2,25],[8,9,10,11,12,13]]

// max 4 by 4 rows of hour glass
/**var hourglass: [Int]
 print(arr[0][0], arr[0][1], arr[0][2])
 print(arr[1][1])
 print(arr[2][0], arr[2][1], arr[2][2])*/

arr.sort()

var counts = [Int: Int]()
var count :Int = 1
var n = 0
while arr.isEmpty == false{
    for n in arr {
        if arr.contains(arr[n]){
            print(n)
            counts[n] = count
            arr.remove(at: n)
        }
    }
}
