import UIKit

var greeting = "Hello, playground"

func saySomething(word1: String){
    print("I'm in love with a \(word1), I'm in love with a \(word1)!")
}
saySomething(word1: "Koko")

func sumOfTwoNumbers(number1: Int, number2: Int) -> Int {
    var total = number1 + number2
    return total
}

var sum = sumOfTwoNumbers(number1: 9, number2: 6)

print("The sum is \(sum)")

