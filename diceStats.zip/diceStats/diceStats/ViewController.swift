//
//  ViewController.swift
//  diceStats
//
//  Created by IACD-017 on 2022/05/13.
//

import UIKit
import Charts

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        createChart()
    }
    
    private func createChart(){
            
            let barChart = BarChartView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height:        view.frame.size.width) )
            var entries = [BarChartDataEntry]()
            for x in 2..<12 {
                entries.append(BarChartDataEntry(x: Double(x), y: Double.random(in: 1...13)
                                                ))
                               
            }
            let set = BarChartDataSet(entries: entries, label: "Dice Rolls")
            let data = BarChartData(dataSet: set)
            
            barChart.data = data
                               
           view.addSubview(barChart)
            barChart.center = view.center
            
        }


}

